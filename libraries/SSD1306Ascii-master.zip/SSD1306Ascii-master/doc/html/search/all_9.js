var searchData=
[
  ['oledreset',['oledReset',['../_s_s_d1306_ascii_8h.html#a2d24b58760aa70ba784ac7a43b2d3b16',1,'SSD1306Ascii.h']]],
  ['optimize_5favr_5fspi',['OPTIMIZE_AVR_SPI',['../_s_s_d1306_ascii_8h.html#ab2e558664bbba6deb8bd474173d5725e',1,'SSD1306Ascii.h']]],
  ['optimize_5fi2c',['OPTIMIZE_I2C',['../_s_s_d1306_ascii_8h.html#a6dad8e64264884e4d7534b237a188e4a',1,'SSD1306Ascii.h']]]
];
